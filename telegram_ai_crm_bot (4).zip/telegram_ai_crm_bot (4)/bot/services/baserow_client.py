import requests
from typing import Dict, Any, List, Optional
from bot.config import BASEROW_URL, BASEROW_JWT, BASEROW_DATABASE_ID

class Baserow:
    def __init__(self, base_url: str = BASEROW_URL, jwt: str = BASEROW_JWT, db_id: int = BASEROW_DATABASE_ID):
        self.base_url = base_url.rstrip("/")
        self.jwt = jwt
        self.db_id = db_id
        self.headers = {"Authorization": f"JWT {self.jwt}"}

    # --- Tables ---
    def create_table(self, name: str) -> Optional[int]:
        # Официальный эндпоинт: POST /api/database/tables/database/{database_id}/
        resp = requests.post(
            f"{self.base_url}/api/database/tables/database/{self.db_id}/",
            headers=self.headers,
            json={"name": name},
            timeout=30
        )
        if resp.ok:
            return resp.json()["id"]
        # Если уже существует — можно отловить ошибку и вернуть None
        return None

    def list_tables(self) -> List[Dict[str, Any]]:
        r = requests.get(f"{self.base_url}/api/database/tables/database/{self.db_id}/",
                         headers=self.headers, timeout=30)
        r.raise_for_status()
        return r.json()

    def get_table_id_by_name(self, name: str) -> Optional[int]:
        for t in self.list_tables():
            if t.get("name") == name:
                return t.get("id")
        return None

    # --- Fields ---
    def list_fields(self, table_id: int) -> List[Dict[str, Any]]:
        r = requests.get(f"{self.base_url}/api/database/fields/table/{table_id}/",
                         headers=self.headers, timeout=30)
        r.raise_for_status()
        return r.json()

    def ensure_field(self, table_id: int, name: str, ftype: str) -> Optional[int]:
        # Проверка существования
        for f in self.list_fields(table_id):
            if f.get("name") == name:
                return f["id"]
        # Создание поля
        r = requests.post(f"{self.base_url}/api/database/fields/table/{table_id}/",
                          headers=self.headers,
                          json={"name": name, "type": ftype},
                          timeout=30)
        if r.ok:
            return r.json()["id"]
        return None

    # --- Rows ---
    def list_rows(self, table_id: int, **params) -> Dict[str, Any]:
        r = requests.get(f"{self.base_url}/api/database/rows/table/{table_id}/",
                         headers=self.headers, params=params, timeout=30)
        r.raise_for_status()
        return r.json()

    def create_row(self, table_id: int, values: Dict[str, Any]) -> Dict[str, Any]:
        r = requests.post(f"{self.base_url}/api/database/rows/table/{table_id}/",
                          headers=self.headers, json=values, timeout=30)
        r.raise_for_status()
        return r.json()

    def update_row(self, table_id: int, row_id: int, values: Dict[str, Any]) -> Dict[str, Any]:
        r = requests.patch(f"{self.base_url}/api/database/rows/table/{table_id}/{row_id}/",
                           headers=self.headers, json=values, timeout=30)
        r.raise_for_status()
        return r.json()

    def delete_row(self, table_id: int, row_id: int) -> None:
        r = requests.delete(f"{self.base_url}/api/database/rows/table/{table_id}/{row_id}/",
                            headers=self.headers, timeout=30)
        r.raise_for_status()
