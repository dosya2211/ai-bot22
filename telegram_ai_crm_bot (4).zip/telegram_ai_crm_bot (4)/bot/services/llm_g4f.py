from g4f.client import Client
from typing import List, Dict

class LLM:
    def __init__(self):
        self.client = Client()

    def chat(self, messages: List[Dict], model: str = "gpt-4o-mini") -> str:
        # См. примеры client.chat.completions.create в документации g4f
        resp = self.client.chat.completions.create(
            model=model,
            messages=messages,
            web_search=False
        )
        return resp.choices[0].message.content
