import requests
from typing import List, Dict, Any
from bot.services.baserow_client import Baserow
from bot.config import BASEROW_API_URL, BASEROW_JWT

class ObjectsService:
    def __init__(self, baserow: Baserow):
        self.b = baserow
        self.table_id = self.b.get_table_id_by_name("Объекты")

    def add_object(self, title: str, address: str, price: float, district: str, owner_phone: str, assigned_to: int):
        values = {
            "title": title,
            "address": address,
            "price": price,
            "district": district,
            "owner_phone": owner_phone,
            "status": "В работе",
            "assigned_to": assigned_to
        }
        row = self.b.create_row(self.table_id, values)
        return row

    def upload_file(self, file_path: str) -> Dict[str, Any]:
        url = f"{BASEROW_API_URL}/user-files/upload-file/"
        headers = {"Authorization": f"JWT {BASEROW_JWT}"}
        with open(file_path, "rb") as f:
            files = {"file": (os.path.basename(file_path), f, "application/octet-stream")}
            r = requests.post(url, headers=headers, files=files)
        r.raise_for_status()
        return r.json()

    def add_object_with_photos(self, title: str, address: str, price: float, district: str, owner_phone: str, assigned_to: int, photo_paths: List[str]):
        uploaded_files = []
        for p in photo_paths[:4]:
            try:
                res = self.upload_file(p)
                uploaded_files.append({"name": res.get("name")})
            except Exception as e:
                print("Upload failed", e)
        values = {
            "title": title,
            "address": address,
            "price": price,
            "district": district,
            "owner_phone": owner_phone,
            "status": "В работе",
            "assigned_to": assigned_to,
            "photos": uploaded_files
        }
        row = self.b.create_row(self.table_id, values)
        return row

    def search(self, district: str = None, price_min: float = None, price_max: float = None) -> List[Dict]:
        rows = self.b.list_rows(self.table_id, size=1000).get("results", [])
        res = []
        for r in rows:
            try:
                p = float(r.get("price") or 0)
            except Exception:
                p = 0
            d = r.get("district") or ""
            if district and district.lower() not in d.lower():
                continue
            if price_min is not None and p < price_min:
                continue
            if price_max is not None and p > price_max:
                continue
            res.append(r)
        return res
