from typing import List, Dict, Any
from bot.services.baserow_client import Baserow

class TasksService:
    def __init__(self, baserow: Baserow):
        self.baserow = baserow
        self.table_id = self.baserow.get_table_id_by_name("Задачи")

    def add_task(self, title: str, details: str, assigned_to: int, created_by: int, due_date: str = None):
        values = {
            "title": title,
            "details": details,
            "assigned_to": assigned_to,
            "created_by": created_by,
            "status": "open",
            "due_date": due_date
        }
        return self.baserow.create_row(self.table_id, values)

    def list_my_tasks(self, tg_id: int) -> List[Dict]:
        rows = self.baserow.list_rows(self.table_id, size=1000).get("results", [])
        return [r for r in rows if int(r.get("assigned_to") or 0) == int(tg_id)]

    def list_all(self) -> List[Dict]:
        return self.baserow.list_rows(self.table_id, size=1000).get("results", [])
