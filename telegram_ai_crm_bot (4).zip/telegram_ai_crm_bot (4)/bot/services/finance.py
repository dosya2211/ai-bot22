from datetime import datetime
from typing import Dict, Any
from bot.services.baserow_client import Baserow

class FinanceService:
    def __init__(self, baserow: Baserow):
        self.b = baserow
        self.cash_table = self.b.get_table_id_by_name("Общак")

    def register_penalty(self, agent_id: int, reason: str, amount: int = None):
        amount = amount or 300
        values = {
            "amount": amount,
            "type": "Штраф",
            "reason": reason,
            "date": datetime.utcnow().isoformat(),
            "from_agent": agent_id
        }
        if self.cash_table:
            return self.b.create_row(self.cash_table, values)
        return None

    def register_income(self, agent_id: int, amount: int, reason: str = "Поступление"):
        values = {
            "amount": amount,
            "type": "Поступление",
            "reason": reason,
            "date": datetime.utcnow().isoformat(),
            "from_agent": agent_id
        }
        if self.cash_table:
            return self.b.create_row(self.cash_table, values)
        return None

    def summary_for_agent(self, agent_id: int, date_from: str = None, date_to: str = None) -> Dict[str, Any]:
        if not self.cash_table:
            return {"income": 0, "penalties": 0, "net": 0}
        rows = self.b.list_rows(self.cash_table, size=1000).get("results", [])
        inc = 0
        fines = 0
        for r in rows:
            t = r.get("type")
            a = r.get("amount") or 0
            try:
                fa = int(a)
            except Exception:
                fa = 0
            if date_from or date_to:
                d = r.get("date")
                if not d:
                    continue
                from datetime import datetime as _dt
                dpar = _dt.fromisoformat(d)
                if date_from and dpar < _dt.fromisoformat(date_from):
                    continue
                if date_to and dpar > _dt.fromisoformat(date_to):
                    continue
            if t == "Поступление" or t == "Поступление ":
                inc += fa
            elif t == "Штраф":
                fines += fa
        return {"income": inc, "penalties": fines, "net": inc - fines}
