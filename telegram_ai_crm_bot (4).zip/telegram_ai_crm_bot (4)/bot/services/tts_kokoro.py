import requests
from bot.config import KOKORO_URL, KOKORO_VOICE

def tts_to_bytes(text: str, voice: str = None, response_format: str = "mp3") -> bytes:
    voice = voice or KOKORO_VOICE
    # Kokoro-FastAPI реализует OpenAI-совместимый эндпоинт /v1/audio/speech
    payload = {
        "model": "kokoro",
        "input": text,
        "voice": voice,
        "response_format": response_format,
        "speed": 1.0
    }
    r = requests.post(f"{KOKORO_URL.rstrip('/')}/v1/audio/speech", json=payload, timeout=60)
    r.raise_for_status()
    return r.content
