import numpy as np
import hashlib
from typing import List, Dict, Any
from qdrant_client import QdrantClient
from qdrant_client.models import Distance, VectorParams, PointStruct
from sentence_transformers import SentenceTransformer
from bot.config import QDRANT_URL

class Memory:
    def __init__(self, collection: str = "memory", dim: int = 384):
        self.collection = collection
        self.dim = dim
        self.qdrant = QdrantClient(url=QDRANT_URL)
        self.model = None
        try:
            self.model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
            self.dim = self.model.get_sentence_embedding_dimension()
        except Exception:
            # Фолбэк на простую хеш-векторизацию фиксированного размера
            self.model = None
            self.dim = 384
        self._ensure_collection()

    def _ensure_collection(self):
        try:
            exists = self.qdrant.collection_exists(self.collection)
        except Exception:
            exists = False
        if not exists:
            self.qdrant.create_collection(
                collection_name=self.collection,
                vectors_config=VectorParams(size=self.dim, distance=Distance.COSINE),
            )

    def _embed(self, texts: List[str]) -> np.ndarray:
        if self.model:
            emb = self.model.encode(texts, normalize_embeddings=True)
            return np.array(emb, dtype=np.float32)
        # Фолбэк: детерминированный хеш в фиксированный размер
        arr = np.zeros((len(texts), self.dim), dtype=np.float32)
        for i, t in enumerate(texts):
            h = hashlib.sha256(t.encode("utf-8")).digest()
            # Раскладываем байты по вектору циклически
            for j, b in enumerate(h):
                arr[i, j % self.dim] += (b - 128) / 128.0
            # L2-нормализация
            n = np.linalg.norm(arr[i]) + 1e-9
            arr[i] /= n
        return arr

    def upsert_dialog(self, user_id: int, role: str, text: str, meta: Dict[str, Any]):
        vec = self._embed([text])[0].tolist()
        pid = int(hashlib.md5(f"{user_id}-{role}-{text}".encode()).hexdigest()[:12], 16)
        self.qdrant.upsert(
            collection_name=self.collection,
            points=[PointStruct(id=pid, vector=vec, payload={"user_id": user_id, "role": role, **meta})],
        )

    def search(self, query: str, top_k: int = 5) -> List[Dict[str, Any]]:
        vec = self._embed([query])[0].tolist()
        res = self.qdrant.search(collection_name=self.collection, query_vector=vec, limit=top_k)
        return [{"id": r.id, "score": r.score, "payload": r.payload} for r in res]
